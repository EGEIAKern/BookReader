import customtkinter as ctk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

from ui.colors import COLORS


class StatisticsPage:

    CHART_COLORS = {
        "figure": COLORS["bg_card"],
        "axes": COLORS["bg_card"],
        "text": COLORS["text_main"],
        "muted": COLORS["text_muted"],
        "bar": COLORS["accent"],
        "grid": "#45475a",
    }

    def __init__(self, parent, books):
        self.books = books

        ctk.CTkLabel(
            parent,
            text="📊 Статистика чтения",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=COLORS["text_main"],
        ).pack(pady=20)

        stats = self.compute_stats()

        cards = ctk.CTkFrame(parent, fg_color="transparent")
        cards.pack(fill="x", padx=20, pady=10)
        cards.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.card(cards, "Книг", stats["total_books"], 0)
        self.card(cards, "Страниц", stats["total_pages"], 1)
        self.card(cards, "Прочитано", stats["read_pages"], 2)
        self.card(cards, "Завершено", stats["completed"], 3)

        ctk.CTkLabel(
            parent,
            text=f"Общий прогресс: {stats['percent']}%",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=COLORS["accent"],
        ).pack(pady=20)

        if not books:
            ctk.CTkLabel(
                parent,
                text="Добавьте книги в библиотеку, чтобы увидеть график",
                text_color=COLORS["text_muted"],
            ).pack(pady=40)
            return

        self.render_chart(parent)

    def compute_stats(self):
        total_books = len(self.books)
        total_pages = sum(book.total_pages for book in self.books)
        read_pages = sum(book.current_page for book in self.books)
        completed = sum(1 for book in self.books if book.progress >= 100)

        percent = 0
        if total_pages:
            percent = round(read_pages / total_pages * 100, 1)

        return {
            "total_books": total_books,
            "total_pages": total_pages,
            "read_pages": read_pages,
            "completed": completed,
            "percent": percent,
        }

    def render_chart(self, parent):
        titles = [self.shorten_title(book.title) for book in self.books]
        values = [book.progress for book in self.books]
        colors = self.CHART_COLORS

        fig, ax = plt.subplots(figsize=(8, 4))
        fig.patch.set_facecolor(colors["figure"])
        ax.set_facecolor(colors["axes"])

        bars = ax.bar(titles, values, color=colors["bar"], edgecolor=colors["grid"])
        ax.set_ylim(0, 100)
        ax.set_ylabel("Прогресс (%)", color=colors["text"])
        ax.set_title("Прогресс по книгам", color=colors["text"], pad=12)
        ax.tick_params(colors=colors["muted"])
        ax.grid(axis="y", color=colors["grid"], alpha=0.4)
        ax.spines["bottom"].set_color(colors["grid"])
        ax.spines["left"].set_color(colors["grid"])
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        for bar, value in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 2,
                f"{value}%",
                ha="center",
                va="bottom",
                color=colors["text"],
                fontsize=9,
            )

        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=20, pady=20)
        plt.close(fig)

    @staticmethod
    def shorten_title(title, max_length=18):
        if len(title) <= max_length:
            return title
        return title[: max_length - 1] + "…"

    def card(self, parent, title, value, column):
        frame = ctk.CTkFrame(parent, fg_color=COLORS["bg_card"])
        frame.grid(row=0, column=column, padx=8, pady=10, sticky="nsew")

        ctk.CTkLabel(
            frame,
            text=title,
            text_color=COLORS["text_muted"],
        ).pack(pady=(12, 0))

        ctk.CTkLabel(
            frame,
            text=str(value),
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=COLORS["text_main"],
        ).pack(pady=(0, 12))
