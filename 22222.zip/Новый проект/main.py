import customtkinter as ctk

from storage.storage import load_books

from ui.library_page import LibraryPage
from ui.statistics_page import StatisticsPage

from ui.pages.reading_page import ReadingPage
from ui.pages.goal_page import GoalPage
from ui.pages.percent_page import PercentPage
from ui.pages.calculator_page import CalculatorPage

from ui.colors import COLORS


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class BookTrackerApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("📚 Book Tracker Pro")
        self.geometry("1300x850")
        self.minsize(900, 600)

        self.books = load_books()

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.active_button = None
        self.configure(fg_color=COLORS["bg_main"])

        self.create_sidebar()
        self.create_main()

        self.show_library()

    def create_sidebar(self):
        self.sidebar = ctk.CTkFrame(
            self,
            width=260,
            corner_radius=0,
            fg_color=COLORS["bg_sidebar"],
        )
        self.sidebar.grid(row=0, column=0, sticky="ns")

        ctk.CTkLabel(
            self.sidebar,
            text="📚 Book Tracker",
            text_color=COLORS["accent"],
            font=ctk.CTkFont(size=24, weight="bold"),
        ).pack(pady=30)

        self.btn_library = self.create_nav_button("📚 Библиотека", self.show_library)
        self.btn_stats = self.create_nav_button("📊 Статистика", self.show_statistics)
        self.btn_reading = self.create_nav_button("📖 Прогресс", self.show_reading)
        self.btn_goal = self.create_nav_button("🎯 План чтения", self.show_goal)
        self.btn_percent = self.create_nav_button("📊 Страницы по %", self.show_percent)
        self.btn_calc = self.create_nav_button("🧮 Калькулятор", self.show_calculator)

        self.books_count_label = ctk.CTkLabel(
            self.sidebar,
            text=f"Книг: {len(self.books)}",
            text_color=COLORS["text_muted"],
            font=ctk.CTkFont(size=12),
        )
        self.books_count_label.pack(side="bottom", pady=20)

    def create_nav_button(self, text, command):
        btn = ctk.CTkButton(
            self.sidebar,
            text=text,
            height=45,
            anchor="w",
            fg_color="transparent",
            hover_color=COLORS["bg_card"],
            text_color=COLORS["text_main"],
            command=command,
        )
        btn.pack(fill="x", padx=15, pady=5)
        return btn

    def create_main(self):
        self.main = ctk.CTkFrame(self, fg_color="transparent")
        self.main.grid(row=0, column=1, sticky="nsew")

    def clear_main(self):
        for widget in self.main.winfo_children():
            widget.destroy()

    def activate(self, button):
        if self.active_button:
            self.active_button.configure(fg_color="transparent")

        self.active_button = button
        button.configure(fg_color=COLORS["accent"])

    def update_sidebar_counter(self):
        self.books_count_label.configure(text=f"Книг: {len(self.books)}")

    def show_library(self):
        self.activate(self.btn_library)
        self.clear_main()
        LibraryPage(self.main, self.books, on_books_changed=self.update_sidebar_counter)

    def show_statistics(self):
        self.activate(self.btn_stats)
        self.clear_main()
        StatisticsPage(self.main, self.books)

    def show_reading(self):
        self.activate(self.btn_reading)
        self.clear_main()
        ReadingPage(self.main)

    def show_goal(self):
        self.activate(self.btn_goal)
        self.clear_main()
        GoalPage(self.main)

    def show_percent(self):
        self.activate(self.btn_percent)
        self.clear_main()
        PercentPage(self.main)

    def show_calculator(self):
        self.activate(self.btn_calc)
        self.clear_main()
        CalculatorPage(self.main)


if __name__ == "__main__":
    app = BookTrackerApp()
    app.mainloop()
