import json
import os
import tempfile
from pathlib import Path

from models.book import Book

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_ROOT / "data" / "books.json"


def load_books() -> list[Book]:
    if not DATA_FILE.exists():
        return []

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
    except (json.JSONDecodeError, OSError):
        return []

    if not isinstance(data, list):
        return []

    books = []
    for item in data:
        if not isinstance(item, dict):
            continue
        try:
            books.append(Book.from_dict(item))
        except (TypeError, ValueError):
            continue
    return books


def save_books(books: list[Book]) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

    payload = json.dumps(
        [book.to_dict() for book in books],
        ensure_ascii=False,
        indent=4,
    )

    fd, tmp_path = tempfile.mkstemp(
        dir=DATA_FILE.parent,
        prefix=".books_",
        suffix=".tmp",
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        os.replace(tmp_path, DATA_FILE)
    except OSError:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise
